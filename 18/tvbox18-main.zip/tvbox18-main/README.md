### 自用接口：
https://mirror.ghproxy.com/https://raw.githubusercontent.com/qirenzhidao/tvbox18/main/app.json

### Panda Groove（pg）
https://mirror.ghproxy.com/https://raw.githubusercontent.com/qirenzhidao/tvbox18/main/pg/jsm.json

### 多线路（影视app支持多线路，tvbox自测）
https://mirror.ghproxy.com/https://raw.githubusercontent.com/qirenzhidao/tvbox18/main/tvbox.json

#### 香雅情 已更新至2023.12.10(香佬不再公开，此后不再更新)
香雅情 在线接口 https://mirror.ghproxy.com/https://raw.githubusercontent.com/qirenzhidao/tvbox18/main/XYQTVBox/XYQTVBox.json

推送阿里token方法：设备IP:9978	推送 【token@token值】；

比如 token@e5d97dc550624e819065be97691af7be

#### 饭太硬 
https://mirror.ghproxy.com/https://raw.githubusercontent.com/qirenzhidao/tvbox18/main/fan.json
#### 蜂蜜
https://mirror.ghproxy.com/https://raw.githubusercontent.com/qirenzhidao/tvbox18/main/fongmi.json
#### 道长
https://mirror.ghproxy.com/https://raw.githubusercontent.com/qirenzhidao/tvbox18/main/XYQTVBox/drpy_js/drjs_config.json

### APP推荐fongmi的影视 https://github.com/FongMi/Release/tree/main/apk/release

### 纯搬运。侵权联系，删！！！
